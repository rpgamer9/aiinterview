import nltk
import random
import speech_recognition as sr
from flask import Flask, render_template, request, jsonify

nltk.download("punkt")

app = Flask(__name__)

knowledge_base = {
    "id": {
        "nama": ["Saya adalah AI wawancara.", "Nama saya InterviewBot."],
        "pekerjaan": ["Saya membantu dalam wawancara kerja.", "Saya menjawab pertanyaan tentang karier."],
        "pengalaman": ["Saya memiliki pengalaman luas dalam wawancara kerja."],
        "kelebihan": ["Saya rajin, disiplin, dan cepat belajar.", "Saya suka bekerja dalam tim dan berpikir kreatif."],
        "kekurangan": ["Saya kadang terlalu detail dalam pekerjaan.", "Saya butuh waktu untuk beradaptasi dengan tim baru."],
        "gaji": ["Saya ingin gaji yang sesuai dengan pengalaman saya.", "Saya berharap mendapat kompensasi yang layak."],
        "default": ["Maaf, saya tidak mengerti pertanyaan Anda.", "Bisa ulangi dengan kata lain?"]
    },
    "en": {
        "name": ["I am an interview AI.", "My name is InterviewBot."],
        "job": ["I help with job interviews.", "I can answer career-related questions."],
        "experience": ["I have extensive experience in job interviews."],
        "strengths": ["I am diligent, disciplined, and a quick learner.", "I enjoy teamwork and creative thinking."],
        "weaknesses": ["Sometimes, I focus too much on details.", "I take some time to adapt to a new team."],
        "salary": ["I expect a salary that matches my experience.", "I hope for fair compensation."],
        "default": ["Sorry, I don’t understand your question.", "Can you rephrase it?"]
    }
}


def find_answer(question, lang="id"):
    tokens = nltk.word_tokenize(question.lower())
    kb = knowledge_base.get(lang, knowledge_base["id"])  # Default ke Bahasa Indonesia
    for word in tokens:
        if word in kb:
            return random.choice(kb[word])
    return random.choice(kb["default"])

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    data = request.json
    question = data.get("question", "").strip()
    lang = data.get("language", "id")  # Default ke bahasa Indonesia

    if not question:
        return jsonify({"answer": "Silakan masukkan pertanyaan." if lang == "id" else "Please enter a question."})

    response = find_answer(question, lang)
    return jsonify({"answer": response})

if __name__ == "__main__":
    app.run(debug=True)

